// Service worker: owns the GitHub token and performs all GitHub API calls.
// Content scripts never see the token; they send messages here.

const API = 'https://api.github.com';
const REPO_CACHE_TTL_MS = 10 * 60 * 1000;

chrome.action.onClicked.addListener(() => chrome.runtime.openOptionsPage());

const CONTENT_FILES = ['src/gmail.js', 'src/content.js'];
const CONTENT_CSS = ['src/content.css'];

// Inject into Gmail tabs that were already open when the extension was
// installed, updated or reloaded, so users never have to refresh Gmail.
async function injectIntoOpenGmailTabs() {
  const tabs = await chrome.tabs.query({ url: 'https://mail.google.com/*' });
  for (const tab of tabs) {
    try {
      await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: CONTENT_CSS });
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: CONTENT_FILES });
    } catch (e) {
      console.warn('[g2gi] could not inject into tab', tab.id, e.message);
    }
  }
}

chrome.runtime.onInstalled.addListener(({ reason }) => {
  if (reason === 'install') chrome.runtime.openOptionsPage();
  injectIntoOpenGmailTabs();
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  handle(msg)
    .then((data) => sendResponse({ ok: true, data }))
    .catch((err) => sendResponse({ ok: false, error: err.message || String(err) }));
  return true; // keep the channel open for the async response
});

async function handle(msg) {
  switch (msg.type) {
    case 'getSettings':
      return getSettings();
    case 'validateToken':
      return gh('/user', { token: msg.token });
    case 'listRepos':
      return listRepos(Boolean(msg.force));
    case 'listLabels':
      return gh(`/repos/${msg.repo}/labels?per_page=100`);
    case 'createIssue':
      return createIssue(msg);
    case 'injectIntoTab': {
      await chrome.scripting.insertCSS({ target: { tabId: msg.tabId }, files: CONTENT_CSS });
      await chrome.scripting.executeScript({ target: { tabId: msg.tabId }, files: CONTENT_FILES });
      return true;
    }
    default:
      throw new Error(`Unknown message type: ${msg.type}`);
  }
}

async function getSettings() {
  const defaults = {
    token: '',
    defaultRepo: '',
    defaultLabels: [],
    includeThread: false,
    login: '',
  };
  const stored = await chrome.storage.local.get(Object.keys(defaults));
  return { ...defaults, ...stored };
}

async function gh(path, opts = {}) {
  const token = opts.token || (await getSettings()).token;
  if (!token) throw new Error('No GitHub token saved. Open the extension settings.');

  const res = await fetch(API + path, {
    method: opts.method || 'GET',
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
      ...(opts.body ? { 'Content-Type': 'application/json' } : {}),
    },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });

  if (res.status === 401) throw new Error('GitHub rejected the token. Check it in settings.');
  if (res.status === 403) throw new Error('GitHub refused the request (rate limit or missing permission).');
  if (res.status === 404) throw new Error('Repository not found, or the token cannot access its issues.');
  if (!res.ok) {
    let detail = '';
    try { detail = (await res.json()).message || ''; } catch (_) { /* ignore */ }
    throw new Error(`GitHub error ${res.status}${detail ? ': ' + detail : ''}`);
  }
  return res.json();
}

async function listRepos(force) {
  const { repoCache } = await chrome.storage.local.get('repoCache');
  if (!force && repoCache && Date.now() - repoCache.at < REPO_CACHE_TTL_MS) {
    return repoCache.repos;
  }
  const repos = [];
  for (let page = 1; page <= 3; page++) {
    const batch = await gh(
      `/user/repos?per_page=100&page=${page}&sort=pushed&affiliation=owner,collaborator,organization_member`
    );
    repos.push(
      ...batch
        .filter((r) => r.has_issues && !r.archived)
        .map((r) => ({ fullName: r.full_name, private: r.private }))
    );
    if (batch.length < 100) break;
  }
  await chrome.storage.local.set({ repoCache: { at: Date.now(), repos } });
  return repos;
}

async function createIssue({ repo, title, body, labels }) {
  if (!repo) throw new Error('Choose a repository.');
  if (!title || !title.trim()) throw new Error('Title cannot be empty.');
  const issue = await gh(`/repos/${repo}/issues`, {
    method: 'POST',
    body: { title: title.trim(), body: body || '', labels: labels || [] },
  });
  return { number: issue.number, url: issue.html_url };
}
