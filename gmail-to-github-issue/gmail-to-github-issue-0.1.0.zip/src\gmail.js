// Gmail DOM adapter.
// Every Gmail-specific selector lives here. If Gmail changes its markup,
// this is the only file that should need fixing.
//
// Each selector is a list of candidates, tried in order, so one markup change
// does not break the whole extension.

const GmailDom = (() => {
  const S = {
    // subject heading of an open thread
    subject: ['h2[data-thread-perm-id]', 'h2.hP', 'div.ha h2', 'h2[data-legacy-thread-id]'],
    // one message in the thread
    message: ['div[data-message-id]', 'div.adn', 'div[data-legacy-message-id]'],
    // rendered body of a message
    messageBody: ['div.a3s', 'div[data-message-id] div[dir="ltr"]'],
    // sender element; has "email" and "name" attributes
    sender: ['span[email]', 'span.gD'],
    // date element; "title" attribute holds the full date
    date: ['span.g3', 'span[title][tabindex="-1"]'],
  };

  function qAll(root, candidates) {
    for (const sel of candidates) {
      const found = root.querySelectorAll(sel);
      if (found.length) return Array.from(found);
    }
    return [];
  }

  function q(root, candidates) {
    return qAll(root, candidates)[0] || null;
  }

  function isVisible(el) {
    return !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length));
  }

  // Subject headings of threads currently rendered (there can be more than one
  // in split/preview layouts). Hidden ones are skipped.
  function getSubjectElements() {
    return qAll(document, S.subject).filter(isVisible);
  }

  // True when the URL points at a specific thread (a long id after the folder).
  function inThreadView() {
    return /#[^/]+\/[A-Za-z0-9_-]{10,}/.test(location.hash);
  }

  function threadUrl() {
    // https://mail.google.com/mail/u/0/#inbox/FMfcgz...  ->  .../#all/FMfcgz...
    const m = location.href.match(/^(https:\/\/mail\.google\.com\/mail\/u\/\d+\/)#[^/]+\/([^?]+)/);
    return m ? `${m[1]}#all/${m[2]}` : location.href;
  }

  function readMessage(el) {
    const bodyEl = q(el, S.messageBody);
    const senderEl = q(el, S.sender);
    const dateEl = q(el, S.date);
    const text = (bodyEl ? bodyEl.innerText : el.innerText || '').trim();
    return {
      from: senderEl ? (senderEl.getAttribute('name') || senderEl.textContent.trim()) : '',
      fromEmail: senderEl ? senderEl.getAttribute('email') || '' : '',
      date: dateEl ? (dateEl.getAttribute('title') || dateEl.textContent.trim()) : '',
      text,
    };
  }

  // subjectEl may be null when called from the floating fallback button.
  function readThread(subjectEl) {
    const subject = subjectEl
      ? subjectEl.textContent.trim()
      : (document.title.replace(/\s*-\s*[^-]*@[^-]*-\s*Gmail\s*$/, '').trim() || 'Email');
    const messages = qAll(document, S.message)
      .filter(isVisible)
      .map(readMessage)
      .filter((m) => m.text.length > 0);
    return { subject, messages, url: threadUrl() };
  }

  return { SELECTORS: S, getSubjectElements, inThreadView, readThread };
})();
