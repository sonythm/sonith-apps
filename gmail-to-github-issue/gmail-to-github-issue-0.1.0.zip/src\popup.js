const $ = (id) => document.getElementById(id);
const set = (n, state, text) => { $('d' + n).className = 'dot ' + state; $('t' + n).textContent = text; };

$('settings').addEventListener('click', () => chrome.runtime.openOptionsPage());

chrome.storage.local.get(['token', 'login'], ({ token, login }) => {
  if (token) set(1, 'ok', 'GitHub token saved' + (login ? ' (' + login + ')' : ''));
  else set(1, 'bad', 'No GitHub token. Open settings and add one.');
});

function ping(tabId) {
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, { type: 'ping' }, (res) => {
      if (chrome.runtime.lastError || !res) return resolve(null);
      resolve(res);
    });
  });
}

function showTabStatus(res) {
  set(2, 'ok', 'Extension is running in this Gmail tab.');
  if (!res.inThread) {
    set(3, '', 'No email is open. Open an email to see the button.');
  } else if (res.subjects > 0) {
    set(3, 'ok', 'Email open. Button placed next to the subject.');
  } else {
    set(3, 'bad', 'Email open but subject element not found. Floating button shown instead.');
    $('hint').textContent = 'Gmail markup may have changed. Report this so the selectors in src/gmail.js can be updated.';
  }
}

async function activate(tabId) {
  $('hint').textContent = 'Activating…';
  try {
    await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type: 'injectIntoTab', tabId }, (res) => {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        res && res.ok ? resolve() : reject(new Error(res ? res.error : 'No response'));
      });
    });
    const res = await ping(tabId);
    if (res) {
      $('hint').textContent = '';
      $('activate').hidden = true;
      showTabStatus(res);
    } else {
      $('hint').textContent = 'Injected, but the script did not answer. Press F12 in Gmail and check the Console for [g2gi] lines.';
    }
  } catch (e) {
    $('hint').textContent = 'Chrome refused to inject: ' + e.message;
  }
}

chrome.tabs.query({ active: true, currentWindow: true }, async ([tab]) => {
  if (!tab || !tab.url || !tab.url.startsWith('https://mail.google.com/')) {
    set(2, 'bad', 'This tab is not Gmail.');
    $('hint').textContent = 'Open https://mail.google.com and click the icon again.';
    return;
  }
  const res = await ping(tab.id);
  if (res) return showTabStatus(res);

  set(2, 'bad', 'Extension is not running in this Gmail tab.');
  $('hint').textContent = 'Click Activate to inject it now.';
  const btn = $('activate');
  btn.hidden = false;
  btn.addEventListener('click', () => activate(tab.id));
});
