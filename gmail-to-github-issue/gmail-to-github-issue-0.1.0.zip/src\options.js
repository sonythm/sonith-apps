const $ = (id) => document.getElementById(id);
const msg = $('msg');
const setMsg = (t, cls = '') => { msg.className = 'msg ' + cls; msg.textContent = t; };

function send(m) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(m, (res) => {
      if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
      res && res.ok ? resolve(res.data) : reject(new Error(res ? res.error : 'No response'));
    });
  });
}

async function fillRepos(selected) {
  const repos = await send({ type: 'listRepos', force: true });
  $('repo').innerHTML = '<option value="">(none)</option>';
  for (const r of repos) {
    const o = document.createElement('option');
    o.value = r.fullName;
    o.textContent = r.fullName + (r.private ? ' (private)' : '');
    $('repo').appendChild(o);
  }
  if (selected) $('repo').value = selected;
}

async function load() {
  const s = await send({ type: 'getSettings' });
  $('token').value = s.token || '';
  $('labels').value = (s.defaultLabels || []).join(', ');
  $('includeThread').checked = Boolean(s.includeThread);
  if (s.token) {
    try { await fillRepos(s.defaultRepo); } catch (e) { setMsg(e.message, 'err'); }
  }
}

$('test').addEventListener('click', async () => {
  const token = $('token').value.trim();
  if (!token) return setMsg('Paste a token first.', 'err');
  setMsg('Checking…');
  try {
    const user = await send({ type: 'validateToken', token });
    await chrome.storage.local.set({ token, login: user.login });
    await chrome.storage.local.remove('repoCache');
    await fillRepos($('repo').value);
    setMsg(`Connected as ${user.login}. Repositories loaded.`, 'ok');
  } catch (e) {
    setMsg(e.message, 'err');
  }
});

$('save').addEventListener('click', async () => {
  const token = $('token').value.trim();
  const defaultLabels = $('labels').value.split(',').map((s) => s.trim()).filter(Boolean);
  await chrome.storage.local.set({
    token,
    defaultRepo: $('repo').value,
    defaultLabels,
    includeThread: $('includeThread').checked,
  });
  setMsg('Saved.', 'ok');
});

load();
