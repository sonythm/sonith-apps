// Content script: injects the "GitHub issue" button into open Gmail threads
// and shows the issue dialog. All GitHub calls go through background.js.

(() => {
  const BUTTON_CLASS = 'g2gi-button';

  // If an earlier copy of this script is still in the page (extension was
  // reloaded, or the popup re-injected us), shut it down first.
  if (typeof window.__g2giCleanup === 'function') {
    try { window.__g2giCleanup(); } catch (_) { /* ignore */ }
  }
  document.querySelectorAll('.' + BUTTON_CLASS + ', #g2gi-host').forEach((el) => el.remove());
  const MAX_BODY_CHARS = 60000; // GitHub caps issue bodies at 65536

  const GITHUB_ICON =
    '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"/></svg>';

  // ---------- messaging ----------
  function send(msg) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(msg, (res) => {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        if (!res) return reject(new Error('No response from extension background.'));
        res.ok ? resolve(res.data) : reject(new Error(res.error));
      });
    });
  }

  // Status ping from the popup.
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg && msg.type === 'ping') {
      sendResponse({
        ok: true,
        inThread: GmailDom.inThreadView(),
        subjects: GmailDom.getSubjectElements().length,
        url: location.href,
      });
    }
  });

  // ---------- button injection ----------
  const log = (...a) => console.log('[g2gi]', ...a);
  log('content script loaded on', location.href);

  function makeButton(extraClass) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = BUTTON_CLASS + (extraClass ? ' ' + extraClass : '');
    btn.title = 'Create a GitHub issue from this email';
    btn.innerHTML = GITHUB_ICON + '<span>GitHub issue</span>';
    return btn;
  }

  function injectButtons() {
    const subjects = GmailDom.getSubjectElements();
    let injected = 0;
    for (const subject of subjects) {
      const parent = subject.parentElement;
      if (!parent || parent.querySelector('.' + BUTTON_CLASS)) continue;
      const btn = makeButton('');
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        openDialog(GmailDom.readThread(subject));
      });
      subject.insertAdjacentElement('afterend', btn);
      injected++;
    }
    if (injected) log('injected', injected, 'button(s) next to subject');

    // Fallback: a floating button when a thread is open but no subject element was found.
    const haveInline = subjects.length > 0;
    let floating = document.getElementById('g2gi-floating');
    if (!haveInline && GmailDom.inThreadView()) {
      if (!floating) {
        floating = makeButton('g2gi-floating');
        floating.id = 'g2gi-floating';
        floating.addEventListener('click', () => openDialog(GmailDom.readThread(null)));
        document.body.appendChild(floating);
        log('subject element not found; showing floating button');
      }
    } else if (floating) {
      floating.remove();
    }
  }

  let scheduled = null;
  const observer = new MutationObserver(() => {
    if (scheduled) return;
    scheduled = setTimeout(() => {
      scheduled = null;
      injectButtons();
    }, 300);
  });
  observer.observe(document.body, { childList: true, subtree: true });
  const onHash = () => setTimeout(injectButtons, 500);
  window.addEventListener('hashchange', onHash);
  window.__g2giCleanup = () => {
    observer.disconnect();
    window.removeEventListener('hashchange', onHash);
    document.querySelectorAll('.' + BUTTON_CLASS + ', #g2gi-host').forEach((el) => el.remove());
  };
  injectButtons();

  // ---------- body formatting ----------
  function buildBody(thread, includeThread) {
    const msgs = includeThread ? thread.messages : thread.messages.slice(-1);
    const parts = [];
    for (const m of msgs) {
      const who = m.fromEmail ? m.from + ' <' + m.fromEmail + '>' : m.from;
      parts.push('**From:** ' + who + '  \n**Date:** ' + m.date);
      parts.push(m.text);
      parts.push('---');
    }
    parts.push('_Created from Gmail: ' + thread.url + '_');
    let body = parts.join('\n\n');
    if (body.length > MAX_BODY_CHARS) {
      body = body.slice(0, MAX_BODY_CHARS) + '\n\n_[truncated]_';
    }
    return body;
  }

  // ---------- dialog ----------
  const DIALOG_HTML = `
    <style>
      :host { all: initial; }
      .overlay { position: fixed; inset: 0; background: rgba(0,0,0,.45); z-index: 2147483647;
                 display: flex; align-items: center; justify-content: center;
                 font: 14px/1.4 "Google Sans", Roboto, Arial, sans-serif; color: #202124; }
      .card { background: #fff; width: min(680px, 94vw); max-height: 92vh; overflow: auto;
              border-radius: 12px; box-shadow: 0 8px 32px rgba(0,0,0,.3); padding: 20px 24px; box-sizing: border-box; }
      h1 { font-size: 18px; margin: 0 0 16px; font-weight: 500; display: flex; align-items: center; gap: 8px; }
      h1 svg { width: 18px; height: 18px; fill: currentColor; }
      label { display: block; font-size: 12px; color: #5f6368; margin: 12px 0 4px; }
      input[type=text], select, textarea { width: 100%; box-sizing: border-box; border: 1px solid #dadce0;
              border-radius: 6px; padding: 8px 10px; font: inherit; background: #fff; color: inherit; }
      textarea { min-height: 220px; resize: vertical; font-family: ui-monospace, Consolas, monospace; font-size: 12.5px; }
      .labels { display: flex; flex-wrap: wrap; gap: 6px; min-height: 24px; }
      .labels span { display: inline-flex; align-items: center; gap: 4px; border: 1px solid #dadce0;
                     border-radius: 12px; padding: 2px 8px; font-size: 12px; cursor: pointer; user-select: none; }
      .labels span.on { background: #e8f0fe; border-color: #1a73e8; color: #1a73e8; }
      .check { display: flex; align-items: center; gap: 8px; margin-top: 12px; font-size: 13px; }
      .check label { margin: 0; font-size: 13px; color: inherit; }
      .actions { display: flex; justify-content: flex-end; gap: 8px; margin-top: 18px; }
      button { font: inherit; border-radius: 6px; padding: 8px 16px; cursor: pointer; border: 1px solid #dadce0; background: #fff; }
      button.primary { background: #1a73e8; border-color: #1a73e8; color: #fff; }
      button.small { padding: 2px 8px; margin-left: 6px; }
      button:disabled { opacity: .6; cursor: default; }
      .msg { margin-top: 12px; font-size: 13px; }
      .msg.err { color: #c5221f; }
      .msg.ok { color: #188038; }
      .msg a { color: #1a73e8; }
      .muted { color: #5f6368; font-size: 12px; }
    </style>
    <div class="overlay">
      <div class="card" role="dialog" aria-label="Create GitHub issue">
        <h1>${GITHUB_ICON} Create GitHub issue</h1>
        <label>Repository</label>
        <select id="repo"><option value="">Loading repositories...</option></select>
        <label>Title</label>
        <input type="text" id="title">
        <label>Labels <span class="muted" id="labelsHint"></span></label>
        <div class="labels" id="labels"></div>
        <label>Body (Markdown)</label>
        <textarea id="body"></textarea>
        <div class="check">
          <input type="checkbox" id="includeThread">
          <label for="includeThread">Include the whole thread, not just the latest message</label>
        </div>
        <div class="msg" id="msg"></div>
        <div class="actions">
          <button id="cancel">Cancel</button>
          <button id="create" class="primary">Create issue</button>
        </div>
      </div>
    </div>`;

  let host = null;

  function closeDialog() {
    if (host) host.remove();
    host = null;
  }

  async function openDialog(thread) {
    closeDialog();
    host = document.createElement('div');
    host.id = 'g2gi-host';
    const root = host.attachShadow({ mode: 'open' });
    root.innerHTML = DIALOG_HTML;
    document.body.appendChild(host);

    const $ = (id) => root.getElementById(id);
    const repoSel = $('repo');
    const titleIn = $('title');
    const bodyTa = $('body');
    const labelsBox = $('labels');
    const labelsHint = $('labelsHint');
    const includeCb = $('includeThread');
    const msg = $('msg');
    const createBtn = $('create');
    const cancelBtn = $('cancel');

    const setMsg = (text, cls) => {
      msg.className = 'msg ' + (cls || '');
      msg.textContent = text;
    };

    root.querySelector('.overlay').addEventListener('click', (e) => {
      if (e.target === e.currentTarget) closeDialog();
    });
    cancelBtn.addEventListener('click', closeDialog);
    const onKey = (e) => {
      if (e.key === 'Escape') {
        closeDialog();
        document.removeEventListener('keydown', onKey);
      }
    };
    document.addEventListener('keydown', onKey);

    titleIn.value = thread.subject.replace(/^((re|fwd?|fw):\s*)+/i, '').trim() || thread.subject;

    let settings;
    try {
      settings = await send({ type: 'getSettings' });
    } catch (e) {
      setMsg(e.message, 'err');
      return;
    }
    if (!settings.token) {
      setMsg('No GitHub token saved yet. Click the extension icon in the Chrome toolbar to open settings.', 'err');
      createBtn.disabled = true;
      return;
    }

    includeCb.checked = Boolean(settings.includeThread);
    bodyTa.value = buildBody(thread, includeCb.checked);
    includeCb.addEventListener('change', () => {
      bodyTa.value = buildBody(thread, includeCb.checked);
    });

    // ----- labels -----
    const selectedLabels = new Set(settings.defaultLabels || []);

    function renderLabels(names) {
      labelsBox.innerHTML = '';
      for (const name of names) {
        const chip = document.createElement('span');
        chip.textContent = name;
        if (selectedLabels.has(name)) chip.classList.add('on');
        chip.addEventListener('click', () => {
          if (selectedLabels.has(name)) selectedLabels.delete(name);
          else selectedLabels.add(name);
          chip.classList.toggle('on');
        });
        labelsBox.appendChild(chip);
      }
      labelsHint.textContent = names.length ? '(click to toggle)' : '(no labels in this repo)';
    }

    async function loadLabels() {
      labelsBox.innerHTML = '';
      if (!repoSel.value) {
        labelsHint.textContent = '';
        return;
      }
      labelsHint.textContent = 'loading...';
      try {
        const labels = await send({ type: 'listLabels', repo: repoSel.value });
        renderLabels(labels.map((l) => l.name));
      } catch (e) {
        labelsHint.textContent = 'could not load labels';
      }
    }
    repoSel.addEventListener('change', loadLabels);

    // ----- repos -----
    try {
      const repos = await send({ type: 'listRepos' });
      repoSel.innerHTML = '<option value="">Choose a repository...</option>';
      for (const r of repos) {
        const opt = document.createElement('option');
        opt.value = r.fullName;
        opt.textContent = r.fullName + (r.private ? ' (private)' : '');
        repoSel.appendChild(opt);
      }
      const preferred = settings.lastRepo || settings.defaultRepo;
      if (preferred && repos.some((r) => r.fullName === preferred)) repoSel.value = preferred;
      await loadLabels();
    } catch (e) {
      setMsg(e.message, 'err');
    }

    // ----- create -----
    createBtn.addEventListener('click', async () => {
      createBtn.disabled = true;
      setMsg('Creating issue...');
      try {
        const result = await send({
          type: 'createIssue',
          repo: repoSel.value,
          title: titleIn.value,
          body: bodyTa.value,
          labels: Array.from(selectedLabels),
        });
        await chrome.storage.local.set({ lastRepo: repoSel.value });

        msg.className = 'msg ok';
        msg.textContent = 'Created ';
        const link = document.createElement('a');
        link.href = result.url;
        link.target = '_blank';
        link.rel = 'noopener';
        link.textContent = '#' + result.number;
        msg.appendChild(link);
        msg.appendChild(document.createTextNode(' in ' + repoSel.value + '.'));
        const copy = document.createElement('button');
        copy.className = 'small';
        copy.textContent = 'Copy link';
        copy.addEventListener('click', () => {
          navigator.clipboard.writeText(result.url).then(() => {
            copy.textContent = 'Copied';
          });
        });
        msg.appendChild(copy);

        createBtn.textContent = 'Done';
        cancelBtn.textContent = 'Close';
      } catch (e) {
        setMsg(e.message, 'err');
        createBtn.disabled = false;
      }
    });
  }
})();
